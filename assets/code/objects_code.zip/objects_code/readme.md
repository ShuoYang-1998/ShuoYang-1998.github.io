data download please refer to previous work: https://github.com/JosephKJ/OWOD

run: bash run_SA.sh