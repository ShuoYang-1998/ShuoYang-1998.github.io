#train semantic anchor OWOD 
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --config-file ./configs/SementicAnchor/t1/t1_train.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
cp -r output_SA/t1 output_SA/t2
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --resume --config-file ./configs/SementicAnchor/t2/t2_train.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
cp -r output_SA/t2 output_SA/t2_ft
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --resume --config-file ./configs/SementicAnchor/t2/t2_ft.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
cp -r output_SA/t2_ft output_SA/t3
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --resume --config-file ./configs/SementicAnchor/t3/t3_train.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
cp -r output_SA/t3 output_SA/t3_ft
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --resume --config-file ./configs/SementicAnchor/t3/t3_ft.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
cp -r output_SA/t3_ft output_SA/t4
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --resume --config-file ./configs/SementicAnchor/t4/t4_train.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
cp -r output_SA/t4 output_SA/t4_ft
python3 tools/train_net.py --num-gpus 8 --dist-url='tcp://127.0.0.1:52159' --resume --config-file ./configs/SementicAnchor/t4/t4_ft.yaml SOLVER.IMS_PER_BATCH 8 SOLVER.BASE_LR 0.01
